-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 10, 2012 at 05:54 AM
-- Server version: 5.1.36-community-log
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `socialnetwork`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `addressid` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(500) NOT NULL,
  `privacy` int(2) NOT NULL,
  `cityid` int(11) NOT NULL,
  `profileid` int(11) NOT NULL,
  PRIMARY KEY (`addressid`),
  KEY `cityid` (`cityid`),
  KEY `cityid_2` (`cityid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `advertisement`
--

CREATE TABLE IF NOT EXISTS `advertisement` (
  `advtid` int(11) NOT NULL AUTO_INCREMENT,
  `advttitle` varchar(50) NOT NULL,
  `advtdesc` varchar(500) NOT NULL,
  `websitename` varchar(100) NOT NULL,
  `image` varchar(300) NOT NULL,
  `novisitors` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `activationstatus` int(2) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  PRIMARY KEY (`advtid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `albums`
--

CREATE TABLE IF NOT EXISTS `albums` (
  `albumid` int(11) NOT NULL AUTO_INCREMENT,
  `albumname` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `createdat` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`albumid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `chatid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `toid` int(11) NOT NULL,
  `fromid` int(11) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `createdat` datetime NOT NULL,
  PRIMARY KEY (`chatid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `cityid` int(11) NOT NULL AUTO_INCREMENT,
  `countryid` int(11) NOT NULL,
  `city` varchar(50) NOT NULL,
  PRIMARY KEY (`cityid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `commentid` int(11) NOT NULL AUTO_INCREMENT,
  `statusid` int(11) NOT NULL,
  `message` varchar(500) NOT NULL,
  `createdat` datetime NOT NULL,
  `friendid` int(11) NOT NULL,
  PRIMARY KEY (`commentid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `countryid` int(10) NOT NULL AUTO_INCREMENT,
  `countryname` varchar(25) NOT NULL,
  PRIMARY KEY (`countryid`),
  UNIQUE KEY `countryname` (`countryname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `friendlist`
--

CREATE TABLE IF NOT EXISTS `friendlist` (
  `friendlistid` int(11) NOT NULL AUTO_INCREMENT,
  `friendid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `privacy` int(2) NOT NULL,
  `createdat` datetime NOT NULL,
  `subscription` varchar(2) NOT NULL,
  `reqstatus` int(2) NOT NULL,
  PRIMARY KEY (`friendlistid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE IF NOT EXISTS `group` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `imagelogo` varchar(200) NOT NULL,
  `members` int(11) NOT NULL,
  `createdat` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `langid` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(100) NOT NULL,
  `profileid` int(11) NOT NULL,
  PRIMARY KEY (`langid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE IF NOT EXISTS `notification` (
  `notid` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(500) NOT NULL,
  `type` varchar(100) NOT NULL,
  `privacy` int(2) NOT NULL,
  `createdat` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`notid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `photos`
--

CREATE TABLE IF NOT EXISTS `photos` (
  `photoid` int(11) NOT NULL AUTO_INCREMENT,
  `photoname` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `albumid` int(11) NOT NULL,
  `createdat` datetime NOT NULL,
  PRIMARY KEY (`photoid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `profileid` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL,
  `privacy` tinyint(1) NOT NULL DEFAULT '1',
  `dob` date NOT NULL,
  `aboutme` varchar(500) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `relationship` varchar(15) NOT NULL,
  `phoneno` varchar(15) NOT NULL,
  `interest` varchar(250) NOT NULL,
  `education` varchar(250) NOT NULL,
  `hobbies` varchar(300) NOT NULL,
  `favs` varchar(250) NOT NULL,
  `religion` varchar(50) NOT NULL,
  PRIMARY KEY (`profileid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`profileid`, `userid`, `privacy`, `dob`, `aboutme`, `gender`, `relationship`, `phoneno`, `interest`, `education`, `hobbies`, `favs`, `religion`) VALUES
(1, 0, 0, '0000-00-00', '', 'Male', '', '', '', '', '', '', ''),
(2, 0, 1, '1986-05-23', '', 'Male', '', '', '', '', '', '', ''),
(3, 0, 1, '1985-11-30', '', 'Male', '', '', '', '', '', '', ''),
(4, 0, 1, '1985-11-30', '', 'Male', '', '', '', '', '', '', ''),
(5, 0, 1, '1980-05-22', '', 'Male', '', '', '', '', '', '', ''),
(6, 9, 1, '1965-11-26', '', 'Male', '', '', '', '', '', '', ''),
(7, 10, 1, '1980-08-15', '', 'Male', '', '', '', '', '', '', ''),
(8, 11, 1, '1985-11-30', '', 'Male', '', '', '', '', '', '', ''),
(9, 12, 1, '1995-12-18', '', 'Female', '', '', '', '', '', '', ''),
(10, 13, 1, '1992-05-23', '', 'Male', '', '', '', '', '', '', ''),
(11, 14, 1, '1989-06-10', '', 'Female', '', '', '', '', '', '', ''),
(12, 15, 1, '1995-03-18', '', 'Male', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `statusid` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(1000) NOT NULL,
  `createdat` datetime NOT NULL,
  `likes` int(10) NOT NULL,
  `privacy` int(2) NOT NULL,
  `userid` int(2) NOT NULL,
  `sharedid` int(2) NOT NULL,
  PRIMARY KEY (`statusid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `userid` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `emailid` varchar(30) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `picture` varchar(250) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `online` tinyint(1) NOT NULL DEFAULT '1',
  `createdat` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `secque` int(11) NOT NULL,
  `secans` varchar(50) NOT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`,`emailid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userid`, `username`, `password`, `emailid`, `firstname`, `lastname`, `picture`, `active`, `online`, `createdat`, `secque`, `secans`) VALUES
(1, '', '', '', '', '', '', 0, 0, '2012-11-01 07:10:32', 0, ''),
(2, '', 'test', 'aravinda@gmaillc.o', 'aravinda', 'mva', '', 0, 0, '2012-11-01 07:11:04', 0, ''),
(3, '', 'test', 'jaran@gmai.com', 'raj', 'kiran', '', 1, 1, '2012-11-01 07:12:06', 0, ''),
(4, '', 'as', 'sadf@gksk.com', 'raj', 'kiran', '', 1, 1, '2012-11-01 07:14:51', 0, ''),
(5, '', 'rajesh', 'rajesh@gmauii.com', 'rajesh', 'kiran', '', 1, 1, '2012-11-01 07:35:06', 0, ''),
(6, '', 'rwerwer', 'ssd@dsaf.f', 'Mohammed', 'Kalander', '', 1, 1, '2012-11-01 07:36:19', 0, ''),
(7, '', 'ffffffff', '7klndrvv@gmail.com', 'Mohammed', 'Ishrath', '', 1, 1, '2012-11-01 07:40:29', 0, ''),
(8, '', 'iuytre', '7klndr@gmaggil.com', 'Mohammed', 'Ishrath', '', 1, 1, '2012-11-01 07:42:11', 0, ''),
(9, '', '12345', 'kasf@gma.co', 'raj', 'okd', '', 1, 1, '2012-11-01 07:44:08', 0, ''),
(10, 'testme', 'testtest', 'testmail@gmail.com', 'testfn', 'testln', '', 1, 1, '2012-11-01 07:45:48', 0, ''),
(11, '', 'asdfjsa', 'bc@gami.com', 'abc', 'xyz', '', 1, 1, '2012-11-01 07:52:29', 0, ''),
(12, '', 'wer', 'sadf@gksk.wercom', 'fsadf', 'asdf', '', 1, 1, '2012-11-01 08:33:51', 0, ''),
(13, '', 'thisismapa**word', '7klndr@gmail.com', 'Mohammed', 'Kalander', '', 1, 1, '2012-11-04 17:21:36', 0, ''),
(14, '', 'afsakhader', 'k_nisha_aks@yahoo.com', 'Nisha', 'Mukhtar', '', 1, 1, '2012-11-07 07:30:57', 0, ''),
(15, '', 'kingking', 'peter@gmail.com', 'peter', 'king', '', 1, 1, '2012-11-10 05:53:55', 4, 'bnglore');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
